public class Moto extends Veiculo implements Locavel {
    private int cilindradas;

    public Moto(String placa, String marca, String modelo, double valorDiaria, StatusVeiculo status, int cilindradas) {
        super(placa, marca, modelo, valorDiaria, status);
        this.cilindradas = cilindradas;
    }

    @Override
    public double calcularDiariaComDesconto() {
        if (cilindradas <= 200)
            return getValorDiaria() * 0.95; // 5% de desconto
        else
            return getValorDiaria(); // sem desconto
    }

    @Override
    public void iniciarLocacao() {
        if (verificarDisponibilidade()) {
            setStatus(StatusVeiculo.LOCADO);
            System.out.println("Moto alugada!");
        } else {
            System.out.println("Moto não disponível.");
        }
    }

    @Override
    public void encerrarLocacao() {
        setStatus(StatusVeiculo.DISPONIVEL);
        System.out.println("Moto devolvida!");
    }

    @Override
    public boolean verificarDisponibilidade() {
        return getStatus() == StatusVeiculo.DISPONIVEL;
    }
}