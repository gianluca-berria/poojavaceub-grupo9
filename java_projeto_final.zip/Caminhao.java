public class Caminhao extends Veiculo implements Locavel {
    private double capacidadeCarga;

    public Caminhao(String placa, String marca, String modelo, double valorDiaria, StatusVeiculo status, double capacidadeCarga) {
        super(placa, marca, modelo, valorDiaria, status);
        this.capacidadeCarga = capacidadeCarga;
    }

    @Override
    public double calcularDiariaComDesconto() {
        return getValorDiaria() * 1.15; // 15% de acréscimo
    }

    @Override
    public void iniciarLocacao() {
        if (verificarDisponibilidade()) {
            setStatus(StatusVeiculo.LOCADO);
            System.out.println("Caminhão alugado!");
        } else {
            System.out.println("Caminhão não disponível.");
        }
    }

    @Override
    public void encerrarLocacao() {
        setStatus(StatusVeiculo.DISPONIVEL);
        System.out.println("Caminhão devolvido!");
    }

    @Override
    public boolean verificarDisponibilidade() {
        return getStatus() == StatusVeiculo.DISPONIVEL;
    }
}