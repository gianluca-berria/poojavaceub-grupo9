public class Main {
    public static void main(String[] args) {
        Carro carro = new Carro("ABC-1234", "Honda", "Civic", 200, StatusVeiculo.DISPONIVEL, 4);
        Moto moto = new Moto("XYZ-9876", "Yamaha", "Fazer", 100, StatusVeiculo.DISPONIVEL, 150);
        Caminhao caminhao = new Caminhao("JKL-5678", "Volvo", "FH", 500, StatusVeiculo.DISPONIVEL, 20);

        carro.exibirResumo();
        moto.exibirResumo();
        caminhao.exibirResumo();

        carro.iniciarLocacao();
        System.out.println("Valor diária carro: R$ " + carro.calcularDiariaComDesconto());

        moto.iniciarLocacao();
        System.out.println("Valor diária moto: R$ " + moto.calcularDiariaComDesconto());

        caminhao.iniciarLocacao();
        System.out.println("Valor diária caminhão: R$ " + caminhao.calcularDiariaComDesconto());

        carro.encerrarLocacao();
        moto.encerrarLocacao();
        caminhao.encerrarLocacao();
    }
}