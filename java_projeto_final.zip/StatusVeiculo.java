public enum StatusVeiculo {
    DISPONIVEL,
    LOCADO,
    MANUTENCAO;
}