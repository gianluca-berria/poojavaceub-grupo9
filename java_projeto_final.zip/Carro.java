public class Carro extends Veiculo implements Locavel {
    private int portas;

    public Carro(String placa, String marca, String modelo, double valorDiaria, StatusVeiculo status, int portas) {
        super(placa, marca, modelo, valorDiaria, status);
        this.portas = portas;
    }

    @Override
    public double calcularDiariaComDesconto() {
        return getValorDiaria() * 0.9; // 10% de desconto fixo
    }

    @Override
    public void iniciarLocacao() {
        if (getStatus() == StatusVeiculo.DISPONIVEL) {
            setStatus(StatusVeiculo.LOCADO);
            System.out.println("Carro alugado!");
        } else {
            System.out.println("Carro não disponível.");
        }
    }

    @Override
    public void encerrarLocacao() {
        setStatus(StatusVeiculo.DISPONIVEL);
        System.out.println("Carro devolvido!");
    }

    @Override
    public boolean verificarDisponibilidade() {
        return getStatus() == StatusVeiculo.DISPONIVEL;
    }
}